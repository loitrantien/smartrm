﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartRmApi.Models
{
    public class notificaton
    {
        public string message { get; set; }
        public string key { get; set; }
        public string deviceID { get; set; }
    }
}